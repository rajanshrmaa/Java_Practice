package com.example.MVC_Architecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcArchitectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
