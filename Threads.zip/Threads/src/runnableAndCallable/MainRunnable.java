// USE CASE : Creating Worker Threads Using Runnable Interface.

//Runnable Interface : Runnable interface represents tasks that can be executed by Threads. 
// It has a single Method run() with no return type.

package runnableAndCallable;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/*
 *  public interface Runnable{
 *  
 *  	public void run(); 
 *  
 */

class MyRunnable implements Runnable{
	
	@Override
	public void run() {
		
		System.out.println("My Runnable Class : " + Thread.currentThread().getName()); // Currently the thread is executing and get the name of the thread.
		
	}
	
}

public class MainRunnable {
	
	public static void main(String[] args) {
		
		MyRunnable runnable = new MyRunnable(); 
		
		Thread thread =  new Thread(runnable);// passing runnable object to thread.
		
		thread.start(); 
	
		// ExecutorService service = Executors.newFixedThreadPool(2);  
		
		// service.submit(runnable);
		
		// service.shutdown();
		
		
	}

}
