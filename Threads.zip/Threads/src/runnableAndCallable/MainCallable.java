// USE CASE : Creating Worker Threads Using Callable Interface by performing Task on Fetching Bank Details.

// Callable Interface : It is similar to runnable interface,but it can throw checked exception.
// It also has a single method call() with return type.

package runnableAndCallable;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/*
 * public class interface Callable<V> {
 * 	
 * 		v call() throws Exception;
 *  
*/

class MyCallable implements Callable<String>{
	
	
	String BankNAme;
	String AccountType;
	long AccountNumber;
	float AccountBalance;
	
	
	
	public MyCallable(String bankNAme, String accountType, long accountNumber, float accountBalance) {
		
		BankNAme = bankNAme;
		AccountType = accountType;
		AccountNumber = accountNumber;
		AccountBalance = accountBalance;
	}



	   @Override
	    public String call() throws Exception {
	        System.out.println("My Callable Class : " + Thread.currentThread().getName());
	        return "Account Details: " + this.toString();
	    }



	@Override
	public String toString() {
		return "MyCallable [BankNAme=" + BankNAme + ", AccountType=" + AccountType + ", AccountNumber=" + AccountNumber
				+ ", AccountBalance=" + AccountBalance + "]";
	}
	
	
	
}

public class MainCallable {
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		MyCallable callable = new MyCallable("HDFC","Savings",8984848994484l,165.2f);
		
		// Thread only accepts runnable tasks,because it only implements runnable interface.
		
		// Executor Service is an interface which allows to execute the tasks on threads asynchronously, helps in maintaining the pool of threads.
		
		ExecutorService service = Executors.newFixedThreadPool(2);  // 2 thread pools will be created then we can syubmit the tasks to threads.
		
		Future<String> result = service.submit(callable); // Future represents the results of task.
		
		System.out.println(result.get());
		
		service.shutdown();
	}
	

}
