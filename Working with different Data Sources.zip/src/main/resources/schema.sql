Create table bank(

id int primary key,
name varchar(34),
balance int
);