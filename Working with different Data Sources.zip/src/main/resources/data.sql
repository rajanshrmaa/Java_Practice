insert into bank (id, name, balance) values (123, 'Mahesh', 21000);
insert into bank (id, name, balance) values (124, 'Anil', 31000);
insert into bank (id, name, balance) values (125, 'Vinay', 23000);
