package com.repo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.amqp.RabbitProperties.Cache.Connection;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.bean.Bank;

@Repository
public class BankRepo {
	
//	@Autowired
//	DataSource ds;			
//	public int save(Bank bank) {
//		try {
//		Connection con = (Connection) ds.getConnection();
//		PreparedStatement pstmt = ((java.sql.Connection) con).prepareStatement("insert into bank values(?,?,?)");
//		pstmt.setInt(1, bank.getId());
//		pstmt.setString(2, bank.getName());
//		pstmt.setFloat(3, bank.getBalance());
//		return pstmt.executeUpdate();
//		} catch (Exception e) {
//			System.err.println(e);
//			return 0;
//		}
//	}
	
	@Autowired
	private JdbcTemplate template;
	
	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	public void save(Bank bank)
	{
		String sql="insert into bank (id,name,balance) values (?,?,?)";
		int rows=template.update(sql, bank.getId(),bank.getName(), bank.getBalance());
		System.out.println(rows+" rows affected");
	}
	public List<Bank> findAll() {
		String sql="select * from bank";
	
		RowMapper<Bank> mapper=new RowMapper<Bank>() {

			@Override
			public Bank mapRow(ResultSet rs, int rowNum) throws SQLException {
				Bank a=new Bank();
				a.setId(rs.getInt(1));
				a.setName(rs.getString(2));
				a.setBalance(rs.getInt(3));
				return a;
			}
		};
		List<Bank> banks=template.query(sql,mapper);
		
		return banks;
	}

}
