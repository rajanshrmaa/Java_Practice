//use Caes: Working with different Data Sources

package com.main.SpringDemo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.bean.Bank;
import com.repo.BankRepo;

@SpringBootApplication
@ComponentScan(basePackages = {"com.bean", "com.repo"}) // Adjust as necessary
public class SpringDemoApplication {

	public static void main(String[] args) {
		ApplicationContext ac =SpringApplication.run(SpringDemoApplication.class, args);
		
		System.out.println("Spring Boot is up");
		
		Bank bank1=ac.getBean(Bank.class);
		
		bank1.setId(127);
		bank1.setName("karthik");
		bank1.setBalance(5600);
		
		BankRepo repo=ac.getBean(BankRepo.class);
		repo.save(bank1);
		System.out.println(repo.findAll());
	}

}
